"""
3.take a number from the user and check whether even or odd
"""
n=input("Enter a number:")
if n%2==0:
    print "even"
else:
    print "odd"
