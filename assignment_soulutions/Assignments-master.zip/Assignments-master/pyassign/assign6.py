"""
6.take a string from the user and check contains only  alphabets or not?
"""
s=raw_input("Enter a string:")
if s.isalpha():
     print "string contains only alphablets"
else:
    print "strings contains not only alphablets"
