"""
7. take a string from the user and check contains only  special chars or not?
"""
s=raw_input("Enter a string:")
if s.isalnum():
    print "string doesnot contains special chars"
else:
    print "string conatins special chars"
