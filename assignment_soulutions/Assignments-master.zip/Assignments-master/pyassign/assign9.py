"""
9. take a string from the user and check contains only  small letters or not?
"""
s=raw_input("Enter a string:")
if s.islower():
    print "string contains only small letters"
else:
    print "string contains  not only small letters"
