"""
8. take a string from the user and check contains only  capiatl letters or not?
"""
s=raw_input("Enter a string:")
if s==s.lower():
    print "string doesnot contains captials letters"
else:
    print "string contains capital letters"
