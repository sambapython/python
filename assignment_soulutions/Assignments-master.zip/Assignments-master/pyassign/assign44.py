"""
44.l=['1','2','3'] get the sum of the list
"""
l=['1','2','3']
sum1=0
for i in l:
        sum1=sum1+int(i)
print sum1
