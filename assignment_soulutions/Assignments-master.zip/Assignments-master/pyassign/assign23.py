"""
23. Write a program to findout big of two numbers
"""
a=input("Enter first number:")
b=input("Enter second number:")
if a>b:
    print a,"is greater than",b
else:
    print b,"is greater than",a
