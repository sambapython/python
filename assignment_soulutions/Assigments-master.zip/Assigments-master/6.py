u_i=raw_input("Enter input to check given input is alphabates only or not")
if u_i.isalpha():
    print "input contans alphabates only"
else:
    print "input not contains all alphabates "

