"""
35.l=[1,2,3] just make it as a string.
"""
l=[1,2,3]
s=""
for i in l:
      s=s+str(i)
print s
