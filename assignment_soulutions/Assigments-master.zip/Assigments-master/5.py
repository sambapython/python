u_i=raw_input("Enter input to check given input is digits only or not")
if u_i.isdigit():
    print "input contans digits only"
else:
    print "string not contains all digits "

