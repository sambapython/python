"""
45.l1=[1,2,3,4] l2=[5,6,7,8] sum of two lists
"""
l1=[1,2,3,4]
l2=[5,6,7,8]
l=[]
for i in range(len(l1)):
        sum1=l1[i]+l2[i]
        l.append(sum1)
print l
