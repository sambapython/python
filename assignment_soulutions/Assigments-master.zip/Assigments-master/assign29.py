"""
29.names  ="emp1,emp2,emp3,emp4" iterate through the employee names
"""
names  ="emp1,emp2,emp3,emp4"
l=names.split(',')
for i in l:
    print i
