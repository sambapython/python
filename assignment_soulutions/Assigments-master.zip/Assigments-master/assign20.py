"""
20.Take two numbers from the user a,b check whether a is divisible by b or not?
"""
a=input("enter a number:")
b=input("enter a number:")
if b==0:
    print "a is not divisable by b"
else:
    n=a/b
    print "a is divisable by b and result is",n
