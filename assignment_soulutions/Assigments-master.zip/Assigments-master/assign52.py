"""
52. keys=['k1','k2'], values = ['v1','v2'] form a dictionary
"""
keys=['k1','k2']
values=['v1','v2']
d={}
j=0
for i in keys:
        d[i]=values[j]
        j=+1
print d
