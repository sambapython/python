"""
20. Take two numbers from the user a,b check whether a is divisible by b or not?
"""
a=input("enter a number")
b=input("enter second number")

if a%b==0:
    print "a is divisible by b"
else:
    print "a is not divisible by b"
