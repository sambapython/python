"""
6. take a string from the user and check contains only  alphabets or not?
"""
e=raw_input("enter a string")
if e.isalpha()==True:
    print "string contains all alphabets only"
else:
    print "string has other characters also"
