"""
3. take a number from the user and check whether even or odd
"""
num=input("enter a number")
if num%2==0:
    print "even number"
else:
    print "odd number"
