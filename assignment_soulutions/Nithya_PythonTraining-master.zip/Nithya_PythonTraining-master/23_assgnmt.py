"""
23. Write a program to findout big of two numbers
"""
num1=input("enter first number")
num2=input("enter second number")

if num1<num2:
    print "num2 is greater"
else:
    print "num1 is greater"
