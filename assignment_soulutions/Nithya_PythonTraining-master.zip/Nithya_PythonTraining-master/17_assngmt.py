"""
17. Print the first 100 odd numbers
"""
print "odd numbers between 1 to 100 are as given below"
for i in range(100):
    if i%2!=0:
         print i,








        
