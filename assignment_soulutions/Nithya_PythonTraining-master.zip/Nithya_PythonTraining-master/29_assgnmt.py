"""
29.names  ="emp1,emp2,emp3,emp4" iterate through the employee names.
"""
names="emp1,emp2,emp3,emp4"
split_names=names.split(',')
print "Interation through Employee names is:"
for i in split_names:
    print i
    
    
