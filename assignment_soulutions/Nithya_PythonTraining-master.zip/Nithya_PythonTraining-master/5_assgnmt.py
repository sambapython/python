"""
5. take a string from the user and check contains only digits or not?
"""
s=raw_input("Enter a string ")
if s.isdigit()==True:
    print "true:Entered string contains all digits"
else:
    print "false:Entered string contains alphabets"
