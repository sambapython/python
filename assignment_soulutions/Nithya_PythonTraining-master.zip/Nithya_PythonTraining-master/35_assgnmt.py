"""
35.l=[1,2,3] just make it as a string.
"""
l=[1,2,3]
print "Type of list before conversion is ",l,type(l)
k=str(l)
print "Type of list after conversion is",k,type(k)

