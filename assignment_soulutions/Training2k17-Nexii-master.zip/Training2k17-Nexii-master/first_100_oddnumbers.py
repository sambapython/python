a = []
for i in range(100):
    
    if i%2 != 0:
        a.append(i)

print a
#[i for i in range(100) if i%2!=0]
