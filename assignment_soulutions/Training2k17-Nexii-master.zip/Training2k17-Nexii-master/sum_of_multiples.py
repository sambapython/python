b = []
for i in range(1,1000):
    if i%5 == 0:
        b.append(i)

c = sum(b)
print c
