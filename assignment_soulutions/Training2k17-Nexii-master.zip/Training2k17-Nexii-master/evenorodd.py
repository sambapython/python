a = input("Enter the number you want to check whether even or odd: ")
if a%2 == 0:
    #print "The given  number {0} is : even".format(a)
    print "The given number %d is even" %(a)
else:
    #print "The given number {0} is : odd".format(a)
    print "The given number %d is odd" %(a)
