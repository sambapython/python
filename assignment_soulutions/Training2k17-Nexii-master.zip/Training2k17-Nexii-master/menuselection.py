while True:
    print "1.MAC\n2.Linux\n3.Windows"
    a = raw_input("Select One Option: ")
    if a == "1":
        print "MAC"
    elif a == "2":
        print "Linux"
    elif a == "3":
        print "Windows"
    else:
        print "Wrong selection"
        break
        
    
    
