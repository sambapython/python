a = raw_input("Enter the actual string: ")
b = raw_input("Enter the substring: ")
if b in a:
    print "Substring is present in the actual string"

else:
    print "Substring is not found"
