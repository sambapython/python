a = input("Enter number1: ")
b = input("Enter number2: ")
if a%b == 0:
    print " Number1 is divisible by Number2"
else:
    print " Number1 is not divisible by Number2"
